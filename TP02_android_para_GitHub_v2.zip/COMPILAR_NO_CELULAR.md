# Compilar APK do TP02 sem computador

Este projeto contém um fluxo de compilação (`.github/workflows/build-apk.yml`) que usa os servidores do GitHub para gerar um **APK de debug**. Não transforma um ZIP em APK por renomeação: o código Java precisa de uma compilação Android verdadeira.

## Melhor caminho se você está apenas com o celular

1. Criar **um repositório dedicado**, por exemplo `tp02-imagem-real`, no GitHub pelo celular. **Não usar o repositório MESA**.
2. Colocar nele os arquivos deste projeto **descompactados e preservando a estrutura de pastas**, inclusive a pasta oculta `.github/workflows`.
3. No GitHub, abrir a aba **Actions**, selecionar **Compilar APK TP02** e executar **Run workflow** (ou verificar a execução acionada pelo push na branch `main`).
4. Se a compilação terminar em verde, abrir a execução e, em **Artifacts**, baixar `tp02-imagem-real-apk-debug`.
5. Extrair o ZIP do artifact no celular; dentro estará o arquivo `app-debug.apk`.
6. Instalar o APK só se a origem do arquivo for o workflow do seu próprio repositório. Conceder as permissões de câmera e dispositivos por perto.

Se o Android bloquear a instalação, siga somente o fluxo de permissão de instalação de APK de fonte confiável; **nunca desative Play Protect**. A instalação é experimental e de sua responsabilidade.

**Não foi feita compilação deste projeto neste ambiente**, pois não há SDK Android disponível. O workflow precisa ser testado; um erro de compilação não prova incompatibilidade do TP02. O APK tampouco será considerado funcional antes de mostrar a imagem na telinha.

## Teste web alternativo (mais simples)

Use o arquivo separado `TP02_Web_Teste/index.html`, publique via HTTPS (como GitHub Pages) e abra no **Chrome Android**. Ele acessa a câmera e o BLE diretamente, sem APK. Esta abordagem depende de suporte do navegador, pode ser mais lenta e não garante o protocolo de imagem.
