# TP02 Imagem Real — primeiro protótipo de interoperabilidade (0.1.0)

**Destinado exclusivamente ao LYNXZ TP02 do usuário.** Projeto Android em Java, sem acesso à internet, sem SDK ou código copiado do Capar, que tenta enviar um **JPEG real capturado da câmera do Samsung** ao monitor por BLE.

## Estado real (obrigatório ler)

- **Implementado no código:** câmera traseira real com prévia, busca BLE por `SelfieCom`, conexão GATT, assinatura de notificações, interpretação de quatro botões, leitura do comando de abertura e resolução do monitor, resposta `AA 55 01 01`, compressão de JPEG e envio fragmentado na característica WRITE_NO_RESPONSE.
- **Ainda não comprovado:** compilação neste ambiente (não contém Android SDK/Gradle); execução no Samsung; aceitação/exibição de JPEG pelo firmware do TP02; streaming contínuo; foto/vídeo.
- **Sem contorno de licença:** o app não tenta falsificar ou remover verificações de licença ou identificação. Se um requisito de ativação legítimo impedir o espelhamento, será necessário um caminho autorizado.
- **É um experimento, não produto pronto.** Afirmar que o TP02 já mostrou a imagem seria incorreto.

## Como abrir e compilar

1. Num PC com **Android Studio**, `File > Open` e seleciona esta pasta.
2. Espera a sincronização Gradle. Se for solicitado, instala **Android SDK 35** e Java 17; a IDE gerencia isso.
3. Liga o Samsung ao computador via USB e autoriza a depuração USB **se desejas instalar diretamente**, ou usa `Build > Build APK(s)` e transfere o APK de depuração ao Samsung.
4. Instala e abre `TP02 Imagem Real (Teste)`; autoriza **Câmera** e **Dispositivos por perto**.
5. **Fecha Capar e nRF Connect** para liberar o TP02, liga-o e toca `CONECTAR SELFIECOM`.
6. Procura no log `Abertura solicitada: 160x192...` e `resposta de abertura`.
7. Quando houver `Quadro solicitado pelo TP02`, o app captura a câmera real e manda JPEG; também existe o botão **ENVIAR FOTO REAL AO TP02** para teste manual.
8. Só confirma sucesso depois de verificar **com os olhos a imagem real aparecendo na telinha**. O log `Bytes do JPEG enviados ao Android` **não** comprova recepção nem exibição pelo dispositivo.

## Protocolo medido

| Elemento | Dados |
|---|---|
| Device | `SelfieCom` (BLE; endereço visto em teste `41:42:14:D8:45:7F`) |
| Service | `6e400001-b5a3-f393-e0a9-e50e24dcca9d` |
| App → TP02 | `6e400002-b5a3-f393-e0a9-e50e24dcca9d` (Write without response) |
| TP02 → App | `6e400003-b5a3-f393-e0a9-e50e24dcca9d` (Notify) |
| Botão + | `AA 55 0A 00` |
| Botão - | `AA 55 0B 00` |
| Inverter câmera | `AA 55 06 00` |
| Foto/vídeo | `AA 55 02 00` |
| Abertura observada | `AA 55 01 A0 00 C0 00 00 00 3C 00 00 00 00` — provável 160x192, limite 15360 bytes |
| Resposta identificada no Capar 1.4.4 | `AA 55 01 01` |

**Atenção:** o app precisa de teste real com firmware. O JPEG não recebe cabeçalho próprio nessa versão experimental; a lógica de fragmentação por MTU foi observada na versão 1.4.4 do Capar. Pode haver requisitos adicionais de pacing/ACK/inicialização. A versão do Capar presente no Samsung era 1.5.5.

## Critérios de aceitação

1. BLE conecta, descobre serviço, ativa Notify.
2. TP02 envia comando `01`, app responde abertura.
3. TP02 envia pedido `03` e app envia JPEG real.
4. **A imagem aparece na telinha.** Só então começar vídeo contínuo, latência, comandos e melhorias.

## Arquitetura e segurança

- `Tp02Protocol.java`: UUIDs, comandos e parâmetros. Pode ser testado sem Android.
- `Tp02Ble.java`: scan, GATT, notifications, MTU, escrita BLE em blocos.
- `MainActivity.java`: Camera2, enquadramento, JPEG, logs e UI mínima.
- O app não tem permissão `INTERNET`; imagens são mantidas apenas na memória e enviadas ao acessório BLE selecionado.
- Não instalar o APK antigo do Capar em substituição à versão atual.

## Limites do ambiente de elaboração

Este projeto é fornecido como **código-fonte**, não como um APK compilado, porque o ambiente disponível não contém Android SDK, ferramentas de construção Android e não possui acesso ao smartphone físico. É necessária compilação e validação em Android Studio no PC. A engenharia reversa do APK fornecido pelo usuário foi utilizada apenas como referência para interoperabilidade com o dispositivo.
