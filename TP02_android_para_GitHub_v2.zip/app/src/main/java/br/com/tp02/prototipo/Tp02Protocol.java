package br.com.tp02.prototipo;

import java.util.Arrays;

/** Protocolo de interoperabilidade observado no LYNXZ TP02; não implementa autenticação. */
public final class Tp02Protocol {
    public static final String SERVICE = "6e400001-b5a3-f393-e0a9-e50e24dcca9d";
    public static final String WRITE = "6e400002-b5a3-f393-e0a9-e50e24dcca9d";
    public static final String NOTIFY = "6e400003-b5a3-f393-e0a9-e50e24dcca9d";
    public static final int OPEN_CAMERA = 0x01;
    public static final int CAPTURE_BUTTON = 0x02;
    public static final int REQUEST_FRAME = 0x03;
    public static final int SWITCH_CAMERA = 0x06;
    public static final int VOLUME_PLUS = 0x0A;
    public static final int VOLUME_MINUS = 0x0B;

    public static boolean header(byte[] bytes) {
        return bytes != null && bytes.length >= 4 && (bytes[0] & 255) == 0xAA && (bytes[1] & 255) == 0x55;
    }
    public static int command(byte[] b) { return header(b) ? b[2] & 255 : -1; }
    public static byte[] openAck() { return new byte[]{(byte)0xAA, 0x55, 0x01, 0x01}; }
    /** Exemplo visto no nRF: AA 55 01 A0 00 C0 00 00 00 3C 00 00 00 00. */
    public static OpenParams parseOpen(byte[] bytes) {
        if (command(bytes) != OPEN_CAMERA || bytes.length < 13) return null;
        // Conforme interpretação do APK: width/height são little-endian, depois rotação e buffer size.
        int w = u16(bytes,3), h = u16(bytes,5), rotation = bytes[7] & 255;
        int limit = u32(bytes,8);
        if (w < 32 || h < 32 || w > 1024 || h > 1024 || limit < 256 || limit > 1024 * 1024)
            return null;
        return new OpenParams(w,h,rotation,limit);
    }
    private static int u16(byte[] b, int o) { return (b[o]&255) | ((b[o+1]&255)<<8); }
    private static int u32(byte[] b, int o) { return (b[o]&255) | ((b[o+1]&255)<<8) | ((b[o+2]&255)<<16) | ((b[o+3]&255)<<24); }
    public static String hex(byte[] bytes) {
        if (bytes==null) return "null";
        StringBuilder out = new StringBuilder();
        for(byte b:bytes) out.append(String.format("%02X ", b&255));
        return out.toString().trim();
    }
    public static final class OpenParams {
        public final int width,height,rotation,maxBytes;
        OpenParams(int w,int h,int r,int m){width=w;height=h;rotation=r;maxBytes=m;}
        public String toString(){return width+"×"+height+" rot="+rotation+" buffer="+maxBytes;}
    }
    private Tp02Protocol(){}
}
