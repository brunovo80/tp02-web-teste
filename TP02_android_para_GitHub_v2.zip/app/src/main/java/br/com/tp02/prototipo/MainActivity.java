package br.com.tp02.prototipo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Protótipo: primeira imagem REAL capturada no próprio Samsung, enviada por BLE ao TP02.
 * Importante: o dispositivo ainda não confirmou a exibição; a inicialização exata do firmware
 * pode exigir etapas não documentadas no APK 1.4.4. Nenhuma autenticação/licença é burlada.
 */
public class MainActivity extends Activity implements Tp02Ble.Events, TextureView.SurfaceTextureListener {
    private Tp02Ble ble;
    private TextView status, history;
    private Button connect, shoot;
    private TextureView preview;
    private ImageView framePreview;
    private ScrollView scroll;
    private CameraManager manager;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private final ExecutorService encodeWorker=Executors.newSingleThreadExecutor();
    private volatile Tp02Protocol.OpenParams params;
    private volatile boolean openRequested=false,ackSent=false,cameraReady=false;
    private volatile long lastFrameAt=0;
    private volatile int photoCount=0;
    private boolean frontCamera=false;

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        ble=new Tp02Ble(this,this);
        manager=(CameraManager)getSystemService(CAMERA_SERVICE);
        createUi();
        if(hasPermissions()) initCamera(); else requestAllPermissions();
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String content,int size){
        TextView t=new TextView(this);t.setText(content);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(dp(4),dp(6),dp(4),dp(6));return t;
    }
    private void createUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(14));root.setBackgroundColor(Color.rgb(14,19,29));
        TextView title=label("TP02 • IMAGEM REAL",22);title.setTypeface(null,Typeface.BOLD);root.addView(title);
        status=label("Aguardando câmera e conexão BLE",13);status.setTextColor(Color.rgb(131,217,202));root.addView(status);
        preview=new TextureView(this);preview.setSurfaceTextureListener(this);
        preview.setBackgroundColor(Color.BLACK);
        root.addView(preview,new LinearLayout.LayoutParams(-1,dp(295)));
        LinearLayout buttons=new LinearLayout(this);buttons.setPadding(0,dp(8),0,dp(4));buttons.setOrientation(LinearLayout.HORIZONTAL);
        connect=new Button(this);connect.setText("CONECTAR SELFIECOM");
        buttons.addView(connect,new LinearLayout.LayoutParams(0,dp(60),1));
        connect.setOnClickListener(v->{if(hasPermissions())ble.start();else requestAllPermissions();});
        root.addView(buttons);
        shoot=new Button(this);shoot.setText("ENVIAR FOTO REAL AO TP02");shoot.setEnabled(false);
        root.addView(shoot,new LinearLayout.LayoutParams(-1,dp(56)));
        shoot.setOnClickListener(v->captureAndSend("Toque manual",true));
        TextView info=label("O teste transmite JPEG da câmera traseira por BLE. Não há transmissão para a internet. A exibição no monitor ainda precisa ser confirmada.",12);
        info.setTextColor(Color.LTGRAY);root.addView(info);
        framePreview=new ImageView(this);framePreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(framePreview,new LinearLayout.LayoutParams(-1,dp(78)));
        TextView logTitle=label("DIAGNÓSTICO",13);logTitle.setTypeface(null,Typeface.BOLD);root.addView(logTitle);
        scroll=new ScrollView(this);history=label("",11);history.setTextColor(Color.rgb(191,202,218));scroll.addView(history);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        info("Aplicativo experimental 0.1.0. Não instales APKs de fornecedores desconhecidos.");
    }
    private boolean hasPermissions(){
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return false;
        if(Build.VERSION.SDK_INT>=31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    private void requestAllPermissions(){
        if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},11);
        else requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION},11);
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(code,permissions,grants);
        if(hasPermissions()){info("Permissões autorizadas.");initCamera();}
        else info("Precisamos de câmera e Bluetooth por perto para continuar.");
    }
    private void initCamera(){
        if(cameraThread==null){cameraThread=new HandlerThread("tp02-camera");cameraThread.start();cameraHandler=new Handler(cameraThread.getLooper());}
        if(preview.isAvailable())openCamera();
    }
    @SuppressLint("MissingPermission")
    private void openCamera(){
        if(!hasPermissions() || camera!=null || !preview.isAvailable())return;
        try {
            String choice=null;
            for(String id:manager.getCameraIdList()){
                Integer facing=manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if(facing!=null && facing==(frontCamera?CameraCharacteristics.LENS_FACING_FRONT:CameraCharacteristics.LENS_FACING_BACK)){choice=id;break;}
            }
            if(choice==null){info("Não foi possível encontrar a câmera solicitada.");return;}
            manager.openCamera(choice,new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice d){camera=d;openSession();}
                @Override public void onDisconnected(CameraDevice d){d.close();camera=null;cameraReady=false;info("Câmera desconectada.");}
                @Override public void onError(CameraDevice d,int err){d.close();camera=null;cameraReady=false;info("Erro na câmera: "+err);}
            },cameraHandler);
        }catch(Exception e){info("Erro ao abrir câmera: "+e.getMessage());}
    }
    private void openSession(){
        if(camera==null || !preview.isAvailable())return;
        try{
            SurfaceTexture tex=preview.getSurfaceTexture();tex.setDefaultBufferSize(1280,720);
            Surface surface=new Surface(tex);
            CaptureRequest.Builder req=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            req.addTarget(surface);req.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            camera.createCaptureSession(Arrays.asList(surface),new CameraCaptureSession.StateCallback(){
                @Override public void onConfigured(CameraCaptureSession s){
                    session=s;
                    try{s.setRepeatingRequest(req.build(),null,cameraHandler);cameraReady=true;info("Câmera real ligada.");maybeAck();}
                    catch(CameraAccessException e){info("Falha na prévia: "+e.getMessage());}
                }
                @Override public void onConfigureFailed(CameraCaptureSession s){info("Falha ao configurar câmera.");}
            },cameraHandler);
        }catch(Exception e){info("Não foi possível abrir prévia: "+e.getMessage());}
    }
    private void closeCamera(){
        cameraReady=false;
        if(session!=null){session.close();session=null;}
        if(camera!=null){camera.close();camera=null;}
    }
    @Override public void info(String m){runOnUiThread(()->{
        String line=android.text.format.DateFormat.format("HH:mm:ss",new java.util.Date())+" • "+m+"\n";
        String old=history.getText().toString();
        if(old.length()>13000)old=old.substring(old.length()-9000);
        history.setText(old+line);
        scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
    });}
    @Override public void connected(boolean c){runOnUiThread(()->{
        shoot.setEnabled(c);connect.setText(c?"RECONECTAR SELFIECOM":"CONECTAR SELFIECOM");
        status.setText(c?"SelfieCom conectado • esperando o comando de imagem":"Aguardando conexão BLE");
        if(!c){openRequested=false;ackSent=false;params=null;}
    });}
    @Override public void received(byte[] payload){
        int cmd=Tp02Protocol.command(payload);
        info("TP02 → " + Tp02Protocol.hex(payload));
        if(cmd==Tp02Protocol.OPEN_CAMERA){
            Tp02Protocol.OpenParams p=Tp02Protocol.parseOpen(payload);
            if(p!=null){params=p;openRequested=true;ackSent=false;info("Abertura solicitada: "+p);runOnUiThread(this::maybeAck);}
        } else if(cmd==Tp02Protocol.REQUEST_FRAME){
            // Capar antigo recebe pedido do dispositivo, então envia um quadro já preparado.
            captureAndSend("Quadro solicitado pelo TP02",false);
        } else if(cmd==Tp02Protocol.VOLUME_PLUS || cmd==Tp02Protocol.VOLUME_MINUS){
            info("Botão físico "+(cmd==Tp02Protocol.VOLUME_PLUS?"+":"−")+" recebido.");
        } else if(cmd==Tp02Protocol.SWITCH_CAMERA){
            runOnUiThread(()->{frontCamera=!frontCamera;closeCamera();openCamera();});
        } else if(cmd==Tp02Protocol.CAPTURE_BUTTON){
            photoCount++;info("Botão foto/vídeo: toque #"+photoCount+" (captura local não implementada no teste). ");
        }
    }
    private void maybeAck(){
        if(openRequested && cameraReady && ble.ready() && !ackSent){
            ackSent=true;ble.ackOpen();info("TP02 ← resposta de abertura AA 55 01 01.");
            runOnUiThread(()->status.setText("Câmera aberta • esperando pedido de JPEG"));
        }
    }
    private void captureAndSend(String reason,boolean manually){
        if(!ble.ready() || !cameraReady){info("Ainda sem BLE e câmera prontos.");return;}
        long now=android.os.SystemClock.elapsedRealtime();
        if(!manually && now-lastFrameAt<160)return;
        lastFrameAt=now;
        runOnUiThread(()->{
            if(!preview.isAvailable()){info("Prévia da câmera indisponível.");return;}
            Bitmap src=preview.getBitmap();
            if(src==null){info("Quadro da câmera ainda vazio.");return;}
            Tp02Protocol.OpenParams target=params;
            final int w=target==null?160:target.width;
            final int h=target==null?192:target.height;
            final int budget=target==null?15360:target.maxBytes;
            encodeWorker.execute(()->{
                try {
                    Bitmap fit=crop(src,w,h);
                    byte[] jpg=compress(fit,budget);
                    if(jpg==null){info("Não consegui compactar JPEG para o monitor.");return;}
                    info(reason+": JPEG "+w+"x"+h+", "+jpg.length+" bytes; orçamento "+budget);
                    runOnUiThread(()->framePreview.setImageBitmap(fit));
                    if(!ble.sendJpeg(jpg))info("Não foi possível iniciar o envio; BLE ocupado ou desconectado.");
                    src.recycle();
                }catch(Exception e){info("Erro ao gerar quadro: "+e.getMessage());}
            });
        });
    }
    private Bitmap crop(Bitmap src,int width,int height){
        Bitmap out=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(out);canvas.drawColor(Color.BLACK);
        float sourceRatio=(float)src.getWidth()/src.getHeight(), targetRatio=(float)width/height;
        Rect srcRect;
        if(sourceRatio>targetRatio){int cw=(int)(src.getHeight()*targetRatio),left=(src.getWidth()-cw)/2;srcRect=new Rect(left,0,left+cw,src.getHeight());}
        else {int ch=(int)(src.getWidth()/targetRatio),top=(src.getHeight()-ch)/2;srcRect=new Rect(0,top,src.getWidth(),top+ch);}
        canvas.drawBitmap(src,srcRect,new Rect(0,0,width,height),new Paint(Paint.FILTER_BITMAP_FLAG));
        return out;
    }
    private byte[] compress(Bitmap bmp,int budget){
        int safeBudget=Math.max(1024,Math.min(budget,200000));
        for(int quality=66;quality>=16;quality-=10){
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG,quality,out);
            byte[] bytes=out.toByteArray();
            if(bytes.length<=safeBudget)return bytes;
        }
        // Nunca exceder silenciosamente o orçamento anunciado pelo TP02.
        return null;
    }
    @Override public void onSurfaceTextureAvailable(SurfaceTexture t,int width,int height){initCamera();}
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture t,int w,int h){}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture t){closeCamera();return true;}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture t){}
    @Override public void onDestroy(){super.onDestroy();ble.close();closeCamera();
        if(cameraThread!=null){cameraThread.quitSafely();cameraThread=null;}
        encodeWorker.shutdownNow();
    }
}
