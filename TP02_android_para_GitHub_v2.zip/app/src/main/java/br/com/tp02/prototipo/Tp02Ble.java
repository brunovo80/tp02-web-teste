package br.com.tp02.prototipo;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.util.Arrays;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

/** Somente interoperabilidade BLE com o aparelho fornecido pelo usuário. */
@SuppressLint("MissingPermission") // Permissões são verificadas previamente pela Activity.
public final class Tp02Ble {
    public interface Events {
        void info(String message);
        void connected(boolean active);
        void received(byte[] payload);
    }
    private final Context context;
    private final Events events;
    private final Handler main = new Handler(Looper.getMainLooper());
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic tx;
    private boolean scanning = false, ready = false;
    private int mtu = 23;
    private final AtomicBoolean sending = new AtomicBoolean(false);
    private byte[] queue;
    private int offset;
    private final Runnable feed = this::nextChunk;
    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int type, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            String n = result.getScanRecord() != null ? result.getScanRecord().getDeviceName() : null;
            if (n == null) { try { n = d.getName(); } catch(SecurityException ignored){} }
            if (n != null && n.equalsIgnoreCase("SelfieCom")) {
                events.info("SelfieCom encontrado (RSSI " + result.getRssi() + "). Conectando GATT...");
                stopScan();
                connect(d);
            }
        }
        @Override public void onScanFailed(int code){ events.info("Erro da busca BLE: " + code); stopScan(); }
    };
    public Tp02Ble(Context c,Events e){context=c.getApplicationContext();events=e;}
    public boolean ready(){return ready;}
    public int mtu(){return mtu;}
    public void start() {
        close();
        BluetoothManager bm=(BluetoothManager)context.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter a=bm == null ? null : bm.getAdapter();
        if (a==null || !a.isEnabled()) {events.info("Ativa o Bluetooth antes de conectar.");return;}
        scanner=a.getBluetoothLeScanner();
        if(scanner==null){events.info("Scanner BLE indisponível.");return;}
        try {
            scanning=true;
            ScanSettings opt=new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(null,opt,scanCallback);
            events.info("Buscando SelfieCom (BLE) por até 20s...");
            main.postDelayed(() -> { if (scanning) { stopScan();events.info("SelfieCom não encontrado. Verifica se o TP02 está ligado.");} },20000);
        } catch(Exception ex){events.info("Falha ao buscar: " + ex.getMessage());}
    }
    private void stopScan() {
        if(scanning && scanner != null) try {scanner.stopScan(scanCallback);}catch(Exception ignored){}
        scanning=false;
    }
    private void connect(BluetoothDevice device) {
        try {gatt=device.connectGatt(context,false,callback,BluetoothDevice.TRANSPORT_LE);}
        catch(Exception e){events.info("Conexão GATT falhou: "+e.getMessage());}
    }
    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g,int status,int state) {
            if(status==BluetoothGatt.GATT_SUCCESS && state==BluetoothProfile.STATE_CONNECTED) {
                events.info("BLE conectado. Descobrindo serviços...");g.discoverServices();
            } else if(state==BluetoothProfile.STATE_DISCONNECTED || status!=BluetoothGatt.GATT_SUCCESS) {
                ready=false;sending.set(false);events.connected(false);
                events.info("BLE desconectado / status="+status);
                try {g.close();}catch(Exception ignored){}
                if(gatt==g)gatt=null;
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt g,int status) {
            if(status!=BluetoothGatt.GATT_SUCCESS){events.info("Erro ao descobrir serviços: "+status);return;}
            android.bluetooth.BluetoothGattService s=g.getService(UUID.fromString(Tp02Protocol.SERVICE));
            if(s==null){events.info("Serviço do TP02 não encontrado. Firmware incompatível.");return;}
            tx=s.getCharacteristic(UUID.fromString(Tp02Protocol.WRITE));
            BluetoothGattCharacteristic rx=s.getCharacteristic(UUID.fromString(Tp02Protocol.NOTIFY));
            if(tx==null||rx==null){events.info("Faltam características WRITE/NOTIFY.");return;}
            g.setCharacteristicNotification(rx,true);
            BluetoothGattDescriptor cccd=rx.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
            if(cccd==null){events.info("Descritor CCCD ausente.");return;}
            int ok;
            if(Build.VERSION.SDK_INT>=33)ok=g.writeDescriptor(cccd,BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            else {cccd.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);ok=g.writeDescriptor(cccd) ? 0 : 1;}
            events.info("Ativando NOTIFY (retorno="+ok+")...");
        }
        @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int status){
            if(status!=BluetoothGatt.GATT_SUCCESS){events.info("Falha ao ativar NOTIFY: "+status);return;}
            ready=true;events.connected(true);events.info("NOTIFY ativo. Pedindo MTU 517...");
            g.requestMtu(517);
        }
        @Override public void onMtuChanged(BluetoothGatt g,int size,int status){
            if(status==BluetoothGatt.GATT_SUCCESS) mtu=size;
            events.info("MTU="+mtu+", status="+status+". Aguardando abertura da câmera pelo TP02...");
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value){
            events.received(value.clone());
        }
        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){
            if(Build.VERSION.SDK_INT<33) events.received(c.getValue().clone());
        }
        @Override public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int status){
            if(status!=BluetoothGatt.GATT_SUCCESS)events.info("Falha na escrita BLE: "+status);
        }
    };
    /** Resposta curta ao comando OPEN_CAMERA, após recebê-lo do monitor. */
    public void ackOpen(){if(ready) writeSmall(Tp02Protocol.openAck());}
    public void writeSmall(byte[] bytes){
        if(!ready || sending.get()){events.info("WRITE ignorado: desconectado/ocupado.");return;}
        sendOne(bytes);
    }
    /** Envio em chunks sem cabeçalho (mesma estratégia identificada no APK antigo). */
    public boolean sendJpeg(byte[] jpeg){
        if(!ready || jpeg==null || jpeg.length==0 || !sending.compareAndSet(false,true))return false;
        queue=Arrays.copyOf(jpeg,jpeg.length);offset=0;
        events.info("Enviando JPEG real: "+queue.length+" bytes / payload "+Math.max(20,mtu-3)+" bytes");
        main.post(feed);return true;
    }
    private void nextChunk(){
        if(!ready || queue==null) {sending.set(false);return;}
        if(offset>=queue.length){events.info("Bytes do JPEG enviados ao Android. Exibição no TP02 ainda precisa ser confirmada.");queue=null;sending.set(false);return;}
        int len=Math.min(Math.max(20,mtu-3),queue.length-offset);
        byte[] packet=Arrays.copyOfRange(queue,offset,offset+len);
        if(!sendOne(packet)){
            events.info("Fila BLE ocupada; aguardando próximo envio...");main.postDelayed(feed,45);return;
        }
        offset+=len;
        // Pacotes sem resposta: cadência conservadora para evitar congestionamento.
        main.postDelayed(feed,20);
    }
    private boolean sendOne(byte[] bytes){
        BluetoothGatt g=gatt;BluetoothGattCharacteristic w=tx;
        if(g==null||w==null)return false;
        try{
            if(Build.VERSION.SDK_INT>=33){return g.writeCharacteristic(w,bytes,BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)==BluetoothStatusCodes.SUCCESS;}
            w.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
            w.setValue(bytes);return g.writeCharacteristic(w);
        }catch(Exception e){events.info("WRITE BLE: "+e.getMessage());return false;}
    }
    public void close(){
        stopScan();main.removeCallbacks(feed);sending.set(false);ready=false;tx=null;
        BluetoothGatt old=gatt;gatt=null;
        if(old!=null)try{old.disconnect();old.close();}catch(Exception ignored){}
        events.connected(false);
    }
}
