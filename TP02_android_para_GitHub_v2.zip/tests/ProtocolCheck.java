import br.com.tp02.prototipo.Tp02Protocol;
public class ProtocolCheck {
 public static void main(String[] args) {
  byte[] open = {(byte)0xAA,0x55,0x01,(byte)0xA0,0x00,(byte)0xC0,0x00,0x00,0x00,0x3C,0x00,0x00,0x00,0x00};
  Tp02Protocol.OpenParams p=Tp02Protocol.parseOpen(open);
  if(p==null || p.width!=160 || p.height!=192 || p.maxBytes!=15360 || p.rotation!=0) throw new AssertionError("Parse OPEN: " + p);
  if(!"AA 55 01 01".equals(Tp02Protocol.hex(Tp02Protocol.openAck())))throw new AssertionError("ACK");
  if(Tp02Protocol.command(new byte[]{(byte)0xAA,0x55,0x0A,0x00}) != Tp02Protocol.VOLUME_PLUS)throw new AssertionError("+");
  if(Tp02Protocol.command(new byte[]{(byte)0xAA,0x55,0x0B,0x00}) != Tp02Protocol.VOLUME_MINUS)throw new AssertionError("-");
  if(Tp02Protocol.command(new byte[]{(byte)0xAA,0x55,0x06,0x00}) != Tp02Protocol.SWITCH_CAMERA)throw new AssertionError("switch");
  if(Tp02Protocol.command(new byte[]{(byte)0xAA,0x55,0x02,0x00}) != Tp02Protocol.CAPTURE_BUTTON)throw new AssertionError("photo");
  if(Tp02Protocol.parseOpen(new byte[]{(byte)0xAA,0x55,0x01})!=null)throw new AssertionError("truncated");
  System.out.println("PASSOU: abertura 160x192/15360, ACK, 4 botões e pacote inválido.");
 }
}
